!function(){var SERVER_SIDE_CONFIG={"privacy":{"disableTextCapture":false,"enableSecureCookies":true},"compressCookies":false,"salesforceAura":false,"supportedDomains":[],"replaySettings":{},"integrations":[],"snapshots":{"pageview":{"*":{"j":{"404":function execute() { return $('.error-view').length ? true : false;},"Primary Tag":function execute() { return google_tag_manager['GTM-K3HQ8NT'].dataLayer.get('tags.primaryTag');},"Secondary Tag(s)":function execute() { return google_tag_manager['GTM-K3HQ8NT'].dataLayer.get('tags.secondaryTags');},"Published Date":function execute() { return google_tag_manager['GTM-K3HQ8NT'].dataLayer.get('publishedOn');},"Published Date, Numerical":function execute() { return new Date(google_tag_manager['GTM-K3HQ8NT'].dataLayer.get('publishedOn'));},"Logged In":function execute() { return window.heap.identity == null ? false : true;},"Window Width":function execute() { return window.innerWidth},"Window Height":function execute() { return window.innerHeight},"Screen Density":function execute() { return window.devicePixelRatio},"papaya_y":function execute() { return window.localStorage.getItem("cb_user_traits")},"Nav Dropdown Variation":function execute() { return document.querySelector('meta[name="nav-cta-test"]').content},"Demo Hub CTA Variation":function execute() { return document.querySelector('meta[name="split-test-data"]').content},"papaya_x":function execute() { return window.localStorage.cb_user_traits},"pagePerformanceMetrics":function execute() { return (function() {
  var interval = setInterval(sendTrack, 200);

  function sendTrack() {
    var navigationEntries = window.performance.getEntriesByType("navigation");

    if (navigationEntries.length > 0 && navigationEntries[0].domComplete > 0) {
      var navEntry = navigationEntries[0];
      var domComplete = Math.round(navEntry.domComplete);
      var type = navEntry.type;
      var transferSize = navEntry.transferSize;

      heap.addEventProperties({
        'Page performance | dom Complete': domComplete,
        'Page performance | Type': type,
        'Page performance | Transfer Size': transferSize
      });

      clearInterval(interval);
    }
  }
})();}},"f":{}},"/*":{"j":{"Hotjar App Funnels Impression Tooltip Set up Funnel First":function execute() { return (function() {
  var interval = setInterval(sendTrack, 500);
  var counter = 0

  function sendTrack() {
    counter = counter + 1
    if (counter == 10) {
      clearInterval(interval);
    }
    if (document.querySelectorAll('.css-198739m ef42w1f0 [href="/product-analytics"]').length > 0) {
      heap.track('Hotjar App Funnels Impression Tooltip Set up Funnel First');
      clearInterval(interval);
    }
  }
 })();},"Hotjar App Surveys View New Survey Button":function execute() { return (function() {
  var interval = setInterval(sendTrack, 500);
  var counter = 0

  function sendTrack() {
    counter = counter + 1
    if (counter == 10) {
      clearInterval(interval);
    }
    if (document.querySelectorAll('[data-qa-id="new-survey-btn"]').length > 0) {
      heap.track('Hotjar App Surveys View New Survey Button');
      clearInterval(interval);
    }
  }
 })();},"Product Analytics Cross Sell Nav Shown":function execute() { return (function() {
  var interval = setInterval(sendTrack, 500);
  var counter = 0

  function sendTrack() {
    counter = counter + 1
    if (counter == 10) {
      clearInterval(interval);
    }
    if (document.querySelectorAll('[aria-label="Primary navigation"] [href="/product-analytics"]').length > 0) {
      heap.track('Product Analytics Hotjar Cross Sell Nav Shown');
      clearInterval(interval);
    }
  }
  
})();},"Product Analytics Corss Sell Banner Shown":function execute() { return (function() {
  var interval = setInterval(sendTrack, 500);
  var counter = 0

  function sendTrack() {
    counter = counter + 1
    if (counter == 10) {
      clearInterval(interval);
    }
    if (document.querySelectorAll('.css-1wnk52p.e6tbyp13 [href="/product-analytics"]').length > 0) {
      heap.track('Product Analytics Hotjar Cross Sell Banner Shown');
      clearInterval(interval);
    }
  }
 })();}},"f":{},"s":{"Entry Tags":".entry-tags","test snapshot":"test"},"a":{},"st":{},"ex":{}},"/app*/graph*":{"j":{"Visible metric tabs":function execute() { return (function(){ 
    return
	    $("div[class^='MeasurementSelector-module__container']")       
        .find('button')       
        .map(function(){       		
            return this.innerText
        })
        .toArray()
        .join(', ')
})();}},"f":{}},"/app*/dashboard/*":{"j":{"Dashboard Report Count":function execute() { return $('.dashboard-card').length}},"f":{},"s":{"Dashboard Title":"div.category-or-name-input-static-container.static-name-container.can-edit"}},"*/app/*":{"j":{"Day of Week":function execute() { return (function() { var day; switch (new Date().getDay()) { case 0: day = "Sunday"; break; case 1: day = "Monday"; break; case 2: day = "Tuesday"; break; case 3: day = "Wednesday"; break; case 4: day = "Thursday"; break; case 5: day = "Friday"; break; case 6: day = "Saturday"; } return day; })()},"Hour of Day":function execute() { return (function() { return new Date().getHours(); })()},"Day of Week (UTC)":function execute() { return (function() { var day; switch (new Date().getUTCDay()) { case 0: day = "Sunday"; break; case 1: day = "Monday"; break; case 2: day = "Tuesday"; break; case 3: day = "Wednesday"; break; case 4: day = "Thursday"; break; case 5: day = "Friday"; break; case 6: day = "Saturday"; } return day; })()},"Hour of Day (UTC)":function execute() { return (function() { return new Date().getUTCHours(); })()},"Project: Environment":function execute() { return document.querySelector('.environment-switcher-button').getAttribute('title')}},"f":{},"s":{"Environment Name":".project-and-environment .environment-name","Query Engine Banner Text":"[data-testid=\"heap-on-heap-query-engine-v2-banner\"]","Project Name":".project-and-environment .project-name"}},"/plan-selection":{"j":{},"f":{},"s":{"Plan Selection Page Heading":".plan-selection-heading","Plan Selection Page Heading (H1)":"h1.plan-selection-heading"}},"/blog*":{"j":{},"f":{},"s":{"Author":".entry-meta__author","Category":".mura-item-meta__category"}},"/app/env/*/overview":{"j":{},"f":{},"s":{"page_variation":".overview-top-section-name"}},"/signup":{"j":{},"f":{},"s":{"Error field":".form-error-message"}}},"change":{".Input[type=\"search\"]":{"j":{},"f":{},"t":{"ReadMe Search Term":".Input[type=\"search\"]"}},"[data-qa-id=\"condition-selector__selector\"]":{"a":{},"j":{},"f":{"Main Dropdown Value":"universal-select__trigger-label"},"st":{},"ex":{}}},"click":{"*":{"j":{"Snapshot Target Tag":function execute() { return event.target.tagName.toLowerCase()},"Snapshot Target ID":function execute() { return event.target.id},"Snapshot Target Class":function execute() { return event.target.classList.value},"Snapshot Target Hierarchy":function execute() { return (function() {
  function getHierarchy(target) {
    var tags = [];
    var classes, hierarchy, fullHierarchy, attributes, attributesBlacklist;
    while (target && target.tagName != 'BODY') {
      hierarchy = '@' + target.tagName.toLowerCase() + ';';
      if (target.id) {
        hierarchy += '#' + target.id + ';';
      }
      classes = Array.from(target.classList);
      if (classes.length > 0) {
        hierarchy += '.' + classes.join(';.') + ';';
      }
      attributesBlacklist = ["class", "id", "password", "style", "ng-", "react-id", "value"];
      attributes = target.getAttributeNames().filter(name => !attributesBlacklist.some(substring => name.includes(substring)));
      for (i = 0; i < attributes.length; i++) {
        hierarchy += '[' + attributes[i] + '="' + target.getAttribute(attributes[i]) + '"];';
      }
      tags.unshift(hierarchy);
      target = target.parentElement;
    }
    fullHierarchy = tags.join('|');
    return fullHierarchy;
  }
  return getHierarchy(event.target);
})();}},"f":{}},"button.r-button":{"j":{"Number of Events":function execute() { return $('.symbols-region .symbol-dropdown-region').length},"Number of Group Bys":function execute() { return $('.new-group-by-clause-view').length}},"f":{},"t":{"Date Range":".date-range-dropdown-view .text"},"a":{},"st":{},"ex":{}},".run, [data-heap=view-or-update-results-button]":{"j":{"Number of Events":function execute() { return $('.symbols-region .symbol-dropdown-region').length},"Number of Filters":function execute() { return $('.filter-clause-view').length},"Number of Group Bys":function execute() { return $('.new-group-by-clause-view').length},"Number of Compare Segments":function execute() { return $('.compare-segments-region .symbol-dropdown-region').length},"PoPA Date Range":function execute() { return (function () { var comparisonPeriod = $(event.target).closest('.input').find('.query-region .comparison-date-range-view .text').text(); if ($(event.target).closest('.input').find('.query-region .action-buttons .add-comparison-date-range')[0].style.display === "none") { return comparisonPeriod; } else { return null; }})();},"Total funnel step filter clauses":function execute() { return $(".funnel-subfilter-view .filter-clause-view").length},"Total funnel steps with filter clause":function execute() { return $(".new-funnel-multi-symbol-select-view .outer-wrapper.filtering").length},"Track AppCues Event":function execute() { return (function() {
	if (Appcues) {
		setTimeout(function() {
			Appcues.track('Click - Run Query');
		}, 5000);
	}
})();},"Number of Looker Action Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.includes(':looker:')) {
            count = count + 1
        }
    }
    return count;
})();},"Number of SFDC Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && (element.value.includes(':sfdc:') || element.value.includes(':salesforce:'))) {
            count = count + 1
        }
    }
    return count;
})();},"Number of Hubspot Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.includes(':hubspot:')) {
            count = count + 1
        }
    }
    return count;
})();},"Number of Google Optimize Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.toLowerCase().includes(':google optimize:')) {
            count = count + 1
        }
    }
    return count;
})();},"Number of Optimizely Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.toLowerCase().includes(':optimizely:')) {
            count = count + 1
        }
    }
    return count;
})();},"Number of VWO Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.toLowerCase().includes(':vwo:')) {
            count = count + 1
        }
    }
    return count;
})();},"Number of Clearbit Properties":function execute() { return (function() {
    var matchingElements = document.querySelectorAll('.select2-offscreen');
    var count = 0
    for (let element of matchingElements) {
        if (element.type === 'hidden' && element.value !== undefined && element.value.includes(':clearbit:')) {
            count = count + 1
        }
    }
    return count;
})();},"Group By - First Dropdown Value":function execute() { return (function(){ return $('.new-group-by-clause-view')[0].innerText.replace(/\n.*/g, " ").trim() || ''; })();}},"f":{},"t":{"Date Range":".date-range-dropdown-view .text","Date Range Within":".date-range-wrapper.clause-view .wrapper > :nth-child(3) .text","Event Selected":".symbol-dropdown-region"}},"[data-testid=\"list-item-primary\"]":{"j":{"Search Term":function execute() { return document.querySelector('[data-testid="heap-search-filter-input"]').value}},"f":{}},".install-view-link":{"j":{"Track Event to Appcues":function execute() { return Appcues.track("skip installation (Heap snapshot)");}},"f":{}},"button#submit":{"j":{"Keep Me Signed In":function execute() { return document.querySelector('input#remember').checked;}},"f":{}}}},"sdk":{"version":"5.2.9","isExperimentalVersion":false,"domain":"https://cdn.us.heap-api.com","plugins":[]},"ingestServer":"https://c.us.heap-api.com"};function t(e){var n;return-1===e.indexOf('core')&&e.push('core'),e.sort(function(e,n){return e<n?-1:n<e?1:0}).join('-')}function i(){var e=t(SERVER_SIDE_CONFIG.sdk.plugins||[]),n=heap&&heap.clientConfig&&heap.clientConfig.sdk||{},i=n.domain||SERVER_SIDE_CONFIG.sdk.domain,o=encodeURIComponent(n.version||SERVER_SIDE_CONFIG.sdk.version),r;return i+'/v5/'+(n.version||!SERVER_SIDE_CONFIG.sdk.isExperimentalVersion?'heapjs-static':'heapjs-experimental')+'/'+o+'/'+e+'/heap.js'}function e(){var e=i(),n=document.createElement('script');n.type='text/javascript',n.src=e,n.async=!0;var e=document.getElementsByTagName('script')[0];e.parentNode.insertBefore(n,e)}window.heap.serverConfig=SERVER_SIDE_CONFIG,window.heap.init(window.heap.envId,window.heap.clientConfig,window.heap.serverConfig),e()}();